# VBA Challenge Readme

This project was created for the 2023 UTSA Data Analytics Bootcap

Both final excel sheets contain the finished solutions for the VBA challenge assignment
A seperate VBA file is also located in the folder that contains only the script used


During the completion of this project I referenced UTSA Data Analytics class resources, as well as other GitHub projects that can be found at these links:

https://github.com/vtyeh/stock-analysis-vba
https://github.com/ermiasgelaye/VBA-challenge
https://github.com/emmanuelmartinezs/stock-analysis
